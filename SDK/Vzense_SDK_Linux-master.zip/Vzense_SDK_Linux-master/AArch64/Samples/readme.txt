1.
modify the macro definition status in Vzense_decmtype.h according to different models of devices. 

2.
FrameViewer_DCAM305 if only for DCAM305;
FrameViewer_DCAM550 is for DCAM550U/DCAM550P/DCAM800/DCAM800LITE, the models have no RGB frame; 
FrameViewer_DCAM560 is for DCAM560/DCAM560CPRO/DCAM560CLITE, only the DCAM560 has no RGB frame; 
FrameViewer_DCAM710 if only for DCAM710; 